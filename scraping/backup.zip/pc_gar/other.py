import time
import random

x = random.Random.randint(random ,5, 10)
print(x)
time.sleep(x)